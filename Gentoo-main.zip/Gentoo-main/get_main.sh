wget https://github.com/nercode-us/Gentoo/raw/refs/heads/main/Gentoo-main.zip
cd ..
rm -f Gentoo-main.zip
cd Gentoo-main/
mv Gentoo-main.zip ../
