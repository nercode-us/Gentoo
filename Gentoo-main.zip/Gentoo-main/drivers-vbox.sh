#!/bin/bash
# Video and Input Drivers for VMWare and VirtualBox
emerge -v x11-drivers/xf86-video-vmware
emerge -v x11-drivers/xf86-video-vboxvideo
emerge -v x11-drivers/xf86-input-vmmouse
emerge -v x11-drivers/xf86-video-fbdev