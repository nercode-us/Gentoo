# https://timeapi.io/swagger/index.html

curl -X 'GET' \
  'https://timeapi.io/api/time/current/zone?timeZone=Europe%2FVilnius' \
  -H 'accept: application/json'
