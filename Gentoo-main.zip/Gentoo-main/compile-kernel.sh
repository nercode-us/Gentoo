#!/bin/bash
cd /usr/src/linux
make localmodconfig
make nconfig
