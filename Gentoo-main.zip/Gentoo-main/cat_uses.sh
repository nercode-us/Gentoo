#!/bin/bash
cat /mnt/gentoo/etc/portage/make.conf

cat /etc/portage/make.conf