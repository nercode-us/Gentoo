#!/bin/bash
chmod +x *.sh