#!/bin/bash
chroot /mnt/gentoo /bin/bash
