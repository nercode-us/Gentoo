#!/bin/bash
cd ~
cp Gentoo-main.zip /mnt/gentoo/root/
cd /mnt/gentoo/root/
unzip Gentoo-main.zip
sleep 3
cd Gentoo-main/
bash enter-start.sh