#!/bin/bash
cd ~
mv Gentoo-main.zip /mnt/gentoo/root/
unzip /mnt/gentoo/root/Gentoo-main.zip
sleep 3
cd /mnt/gentoo/root/Gentoo-main/
bash enter-start.sh