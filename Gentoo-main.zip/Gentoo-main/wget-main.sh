cd ..
rm -f Gentoo-main.zip
wget https://github.com/nercode-us/Gentoo/raw/refs/heads/main/Gentoo-main.zip
cd Gentoo-main/
