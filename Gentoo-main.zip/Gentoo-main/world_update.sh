#!/bin/bash
emerge --verbose --update --deep --changed-use @world
