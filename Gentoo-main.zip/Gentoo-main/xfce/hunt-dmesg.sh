#!/bin/bash
dmesg | grep -e '*ERROR*' -e 'fail'