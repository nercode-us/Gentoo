#!/bin/bash
emerge x11-apps/xinit
emerge x11-apps/xclock
emerge x11-terms/xterm
emerge x11-wm/twm