chmod +x *.sh
###
./setup-startx.sh
###
./xfce-full.sh
###
./lightdm.sh
