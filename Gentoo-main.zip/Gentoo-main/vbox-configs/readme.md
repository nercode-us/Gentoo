Kernel configs for VBox.
