
https://github.com/nercode-us/Gentoo/raw/refs/heads/main/Gentoo-main.zip
