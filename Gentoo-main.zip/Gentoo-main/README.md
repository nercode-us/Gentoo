### 1. enter-start.sh
### 2 check-uefi.sh
### 3 check-disk.sh

### 4 format-sdX.sh
### 5 mnt-gentoo.sh
### 6 set-time.sh
### 7 get-stage3.sh
### 8 install-stage3.sh
### 9 set-configs.sh
### 10 mount-linux.sh


https://github.com/nercode-us/Gentoo/raw/refs/heads/main/Gentoo-main.zip
